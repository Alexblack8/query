<?php

session_destroy();



header("Location:http://localhost/webproject/sign-up-login-form/register.php");

?>