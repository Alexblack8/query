<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Welcome to query</title>
  
  
  
      <link rel="stylesheet" href="css/style1.css">

  
</head>

<body>
  <div class="viewport">
   <div class="title">
   
   </div>
 <div class="cards">
  
   <div class="card">
     <div class="card_img card1">
          <div class="plus"><p>+</p></div>
     </div>
     <a href="questions.php">
     <h3>Questions</h3>
     <div class="line">
     </div>
     <p> Ask questions to the student community of iit indore  </p>
     </a>
    
   </div>
   <div class="card">
     <div class="card_img card2">
       <div class="plus"><p>+</p></div>
     </div>
     <a href="notification_homepage.php">
     <h3>Notifications</h3>
     <div class="line">
     </div>
    <p> Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
    </a>
   </div>
   <div class="card">
     <div class="card_img card3">
       <div class="plus"><p>+</p></div>
     </div>
     <a href="feedbacks.php">
     <h3> Feedbacks</h3>
     <div class="line">
     </div>
     <p>Post feedbacks regarding <br/>
                        Mess<br/>
                        Academics<br/>
                        Transort<br/>
                        Sports & Medical Facilities<br/></p>
    </a>
   </div>
   <div class="card">
     <div class="card_img card4">
       <div class="plus"><p>+</p></div>
     </div>
     <a href="user_profile.php?userId=<?php echo $_SESSION['user_id'];?>">
     <h3>Profile</h3>
     <div class="line">
     </div>
     <p>Visit your Profile<br>
                        <span>See the questions and feedbacks<br/>
                        posted by you</span></p></div>
   </a>
   
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js'></script>

  
</body>
</html>
