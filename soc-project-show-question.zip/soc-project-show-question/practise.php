<?php
   $date = date('Y-m-d H:i:s');
   $time=strtotime( $date) / 60;
   echo $time;
?>	